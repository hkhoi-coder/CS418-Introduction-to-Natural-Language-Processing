#write your answer here
import re, string